from .thc import THC
